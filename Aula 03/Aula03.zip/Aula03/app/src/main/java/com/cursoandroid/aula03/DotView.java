package com.cursoandroid.aula03;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

/**
 * Created by Agripino on 23/03/2016.
 */
public class DotView extends View {
    private Dots dots;

    public DotView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setMinimumWidth(400);
        setMinimumHeight(400);
        setFocusable(true);
        dots = new Dots();
    }

    public void setDots(final Dots dots){
        this.dots = dots;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getSuggestedMinimumWidth();
        if(getLayoutParams().width== LayoutParams.WRAP_CONTENT)
        {
            //width = 40;
        }
        else if((getLayoutParams().width==LayoutParams.MATCH_PARENT)||(getLayoutParams().width==LayoutParams.MATCH_PARENT))
        {
            width = MeasureSpec.getSize(widthMeasureSpec);
        }
        else
            width = getLayoutParams().width;


        int height = getSuggestedMinimumHeight();
        if(getLayoutParams().height==LayoutParams.WRAP_CONTENT)
        {

        }
        else if((getLayoutParams().height==LayoutParams.MATCH_PARENT)||(getLayoutParams().height==LayoutParams.MATCH_PARENT))
        {
            height = MeasureSpec.getSize(heightMeasureSpec);
        }
        else
            height = getLayoutParams().height;


        setMeasuredDimension(width|MeasureSpec.EXACTLY, height|MeasureSpec.EXACTLY);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.WHITE);

        Paint paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(hasFocus() ? Color.BLUE : Color.GRAY);
        canvas.drawRect(0, 0, getWidth() - 1, getHeight() - 1, paint);

        paint.setStyle(Paint.Style.FILL);
        for (Dot dot : dots.getDots()) {
            paint.setColor(dot.getColor());
            canvas.drawCircle(dot.getX(), dot.getY(), dot.getDiameter(), paint);
        }
    }
}

