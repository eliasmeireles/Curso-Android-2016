package com.cursoandroid.aula03;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Agripino on 23/03/2016.
 */
public class Dots {
    public interface DotsChangeListener {
        void onDotsChange(Dots dots);
    }
    private final LinkedList<Dot> dots = new LinkedList<Dot>();
    private DotsChangeListener dotsChangeListener;
    private final List<Dot> safeDots = Collections.unmodifiableList(dots);
    public List<Dot> getDots() {
        return safeDots;
    }
    public void setDotsChangeListener(DotsChangeListener l) {
        dotsChangeListener = l;
    }
    public void addDot(float x, float y, int color, int dim) {
        dots.add(new Dot(x, y, color, dim));
        notifyListener();
    }
    public void clearDots() {
        dots.clear();
        notifyListener();
    }
    public Dot getLastDot() {
        return (dots.size()<=0)?null:dots.getLast();
    }
    private void notifyListener() {
        if (null != dotsChangeListener) {
            dotsChangeListener.onDotsChange(this);
        }
    }
}
