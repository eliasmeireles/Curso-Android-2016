package com.cursoandroid.aula03;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by Agripino on 23/03/2016.
 */
public class TrackingTouchListener implements View.OnTouchListener {
    private final Dots mDots;

    TrackingTouchListener(Dots dots) {
        mDots = dots;
    }

    private void addDot(Dots dots, float x, float y, float p, float s) {
        dots.addDot(x, y, Color.CYAN, (int) ((p * s * MainActivity.DOT_DIAMETER) + 1));
    }

    public boolean onTouch(View v, MotionEvent evt) {
        if(!v.hasFocus()) {
            v.requestFocusFromTouch();
        }
        switch (evt.getAction()) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0, n = evt.getHistorySize(); i < n; i++) {
                    addDot(mDots, evt.getHistoricalX(i),
                            evt.getHistoricalY(i),
                            evt.getHistoricalPressure(i),
                            evt.getHistoricalSize(i));
                }
                break;
            default:
                return false;
        }
        addDot(mDots, evt.getX(), evt.getY(), evt.getPressure(), evt.getSize()); return true;
    }
}

