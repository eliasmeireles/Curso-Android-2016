package com.cursoandroid.aula04;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Created by Agripino on 27/03/2016.
 */
public class ImageAdapter extends BaseAdapter {
    int mGalleryItemBackground;
    private Context mContext;

    private Integer[] mImageIds = {
            R.drawable.gallery_photo_1,
            R.drawable.gallery_photo_2, R.drawable.gallery_photo_3,
            R.drawable.gallery_photo_4, R.drawable.gallery_photo_5,
            R.drawable.gallery_photo_6, R.drawable.gallery_photo_7,
            R.drawable.gallery_photo_8 };

    public ImageAdapter(Context context){
            mContext = context;
    }
    @Override
    public int getCount() { return mImageIds.length; }
    @Override
    public Object getItem(int position) { return mImageIds[position]; }
    @Override
    public long getItemId(int position) { return position; }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView i = new ImageView(mContext);
        i.setImageResource(mImageIds[position]);
        i.setScaleType(ImageView.ScaleType.FIT_XY);
        i.setLayoutParams(new LinearLayout.LayoutParams(180, 180));
        i.setBackgroundResource(mGalleryItemBackground);
        return i;
    }
}
