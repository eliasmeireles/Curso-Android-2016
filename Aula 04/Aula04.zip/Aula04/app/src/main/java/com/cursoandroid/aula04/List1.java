package com.cursoandroid.aula04;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Agripino on 28/03/2016.
 */
public class List1 extends ListActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setListAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mStrings));
        registerForContextMenu(getListView());
        getListView().setTextFilterEnabled(true);
        initList();
    }

    private void initList(){
        String[] mStringsAux = {"Alexia", "Bruna", "Carla",
                "Daniele", "Erica", "Fernanda", "Glauberlaine",
                "Heleonora", "Ivana", "Janete", "Kenia", "Luciana",
                "Marta", "Norma", "Osma", "Patricia"};

        for (String s : mStringsAux) {
            mStrings.add(s);
        }
    }

    private final int del = 1;
    private final int up = 2;
    private final int down = 3;
    private final int down_1 = 4;
    private List<String> mStrings = new ArrayList<>();
    public final void onCreateContextMenu(final ContextMenu menu,
                                          final View v,
                                          final ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, del, Menu.NONE, R.string.excluir);
        menu.add(Menu.NONE, up, Menu.NONE, R.string.subir);
        menu.add(Menu.NONE, down, Menu.NONE, R.string.descer);
        menu.add(Menu.NONE, down_1, Menu.NONE, R.string.descer_1);
    }

    public final boolean onContextItemSelected(final MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        ListAdapter adapter = getListAdapter();
        String e = (String) adapter.getItem((int) info.id);
        switch (item.getItemId()) {
            case del:
                mStrings.remove(e);
                break;
            case up:
                mStrings.remove(e);
                mStrings.add(0, e);
                break;
            case down:
                mStrings.remove(e);
                mStrings.add(e);
                break;
            case down_1:
                int pos = mStrings.indexOf(e);
                if(pos + 1 != mStrings.size()) {
                    mStrings.remove(e);
                    mStrings.add(pos + 1, e);
                }
                break;
            default:
                return super.onContextItemSelected(item);
        }
        this.setListAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mStrings));
        return true;
    }
}


