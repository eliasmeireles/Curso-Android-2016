package com.cursoandroid.aula04;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button button;
    private ImageButton imageButton;
    private CheckBox checkBox;
    private TextView textViewElementoEscolhido;
    private Spinner spinner;
    private TextView textViewSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.editText1);
        button = (Button) findViewById(R.id.buttonLogIt);
        imageButton = (ImageButton) findViewById(R.id.imageButton);
        checkBox = (CheckBox) findViewById(R.id.checkBox1);
        textViewElementoEscolhido = (TextView) findViewById(R.id.textViewElementoEscolhido);
        spinner = (Spinner) findViewById(R.id.spinner1);
        textViewSpinner = (TextView) findViewById(R.id.textViewSpinner);

        button.setOnClickListener(btnLogItOnClick);

        checkBox.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox.isChecked()) {
                    checkBox.setText(R.string.checkbox_caixa_marcada);
                } else {
                    checkBox.setText(R.string.checkbox_caixa_desmarcada);
                }
            }
        });

        List<String> lsSpinner = new ArrayList<>();
        lsSpinner.add("Athos");
        lsSpinner.add("Porthos");
        lsSpinner.add("Aramis");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lsSpinner);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                textViewSpinner.setText((String) parent.getItemAtPosition(position));
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                textViewSpinner.setText(R.string.nada_escolhido_ainda);
            }
        });
    }

    public void radioOnclick(View v){
        RadioButton radioButton = (RadioButton) v;
        textViewElementoEscolhido.setText(radioButton.getText());
    }

    private final Button.OnClickListener
            btnLogItOnClick = new Button.OnClickListener(){
        public void onClick(View v){
            String texto = editText.getText().toString();
            // imprimir o texto na saída do Log
            Log.v("Aula04", texto);
            editText.setText("");
        }
    };
}
