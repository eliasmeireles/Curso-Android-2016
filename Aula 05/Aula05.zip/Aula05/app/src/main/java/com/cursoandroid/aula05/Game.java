package com.cursoandroid.aula05;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

/**
 * Created by Agripino on 11/04/2016.
 */
public class Game extends AppCompatActivity {
    public static final String KEY_DIFFICULTY = "KEY_DIFFICULTY";
    public static final int DIFFICULT_EASY = 0;
    public static final int DIFFICULT_MEDIUM = 1;
    public static final int DIFFICULT_HARD = 2;
    private static final String TAG = "Sudoku";
    private int puzzle[] = new int[9 * 9];
    private int used[][][] = new int[9][9][];
    private PuzzleView puzzleView;

    private String currentPuzzle;
    private final String easyPuzzle =
            "360000000004230800000004200" +
                    "070460003820000014500013020" +
                    "001900000007048300000000045";
    private final String mediumPuzzle =
                    "650000070000506000014000005" +
                    "007009000002314700000700800" +
                    "500000630000201000030000097";
    private final String hardPuzzle =
                    "009000000080605020501078000" +
                    "000000700706040102004000000" +
                    "000720903090301080000000600";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        int difficulty = getIntent().getIntExtra(KEY_DIFFICULTY, DIFFICULT_EASY);
    }

    public String getTileString(int x, int y) {
        return "x";
    }

    private int getTile(int x, int y) {
        return puzzle[y * 9 + x];
    }
    private void setTile(int x, int y, int value) {
        puzzle[y * 9 + x] = value;
    }

    protected int[] getUsedTiles(int x, int y){
        return used[x][y];
    }

    protected boolean setTileIfValid(int x, int y, int value) {
        // Não permitir alterar a sposições preenchidas inicialmente (puzzle inicial)
        if(fromPuzzleString(currentPuzzle)[y * 9 + x] != 0){
            return false;
        }
        int tiles[] = getUsedTiles(x, y);
        if (value != 0) {
            for (int tile : tiles) {
                if (tile == value)
                    return false;
            }
        }
        setTile(x, y, value);
        calculateUsedTiles();
        return true;
    }

    private void calculateUsedTiles() {
        for (int x = 0; x < 9; x++) {
            for (int y = 0; y < 9; y++) {
                used[x][y] = calculateUsedTiles(x, y);
            }
        }
    }

    private int[] calculateUsedTiles(int x, int y) {
        int c[] = new int[9];
        // horizontal
        for (int i = 0; i < 9; i++) {
            if (i == y)
                continue;
            int t = getTile(x, i);
            if (t != 0)
                c[t - 1] = t;
        }
        // vertical
        for (int i = 0; i < 9; i++) {
            if (i == x)
                continue;
            int t = getTile(i, y);
            if (t != 0)
                c[t - 1] = t;
        }
        // same cell block
        int startx = (x / 3) * 3;
        int starty = (y / 3) * 3;
        for (int i = startx; i < startx + 3; i++) {
            for (int j = starty; j < starty + 3; j++) {
                if (i == x && j == y)
                    continue;
                int t = getTile(i, j);
                if (t != 0)
                    c[t - 1] = t;
            }
        }
        // compress
        int nused = 0;
        for (int t : c) {
            if (t != 0)
                nused++;
        }
        int c1[] = new int[nused];
        nused = 0;
        for (int t : c) {
            if (t != 0)
                c1[nused++] = t;
        }
        return c1;
    }

    private int[] getPuzzle(int diff) {
        String puz;
        switch (diff) {
            case DIFFICULT_HARD:
                puz = hardPuzzle;
                break;
            case DIFFICULT_MEDIUM:
                puz = mediumPuzzle;
                break;
            case DIFFICULT_EASY:
            default:
                puz = easyPuzzle;
                break;
        }
        // Guardar o puzzle inicial para bloquear mudanças as posições pré-preenchidas
        currentPuzzle = puz;
        return fromPuzzleString(puz);
    }

    static private String toPuzzleString(int[] puz) {
        StringBuilder buf = new StringBuilder();
        // TODO: IMPLEMENTAR AQUI O MÉTODO PARA RETORNAR UMA STRING A PARTIR DE UM ARRAY DE INTEIROS
        return buf.toString();
    }

    static protected int[] fromPuzzleString(String string) {
        int[] puz = new int[string.length()];
        // TODO: IMPLEMENTAR AQUI O MÉTODO PARA RETORNAR UM ARRAY DE INTEIROS CRIADOS A PARTIR DA STRING
        return puz;
    }

    protected void showKeypadOrError(int x, int y) {
        int tiles[] = getUsedTiles(x, y);
        if (tiles.length == 9) {
            Toast toast = Toast.makeText(this, R.string.no_moves_label, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        } else {
            Dialog v = new Keypad(this, tiles, puzzleView);
            v.show();
        }
    }
}
