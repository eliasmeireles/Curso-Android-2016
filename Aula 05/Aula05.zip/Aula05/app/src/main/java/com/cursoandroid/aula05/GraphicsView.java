package com.cursoandroid.aula05;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;

/**
 * Created by Agripino on 11/04/2016.
 */
public class GraphicsView extends View {

    private int height;
    private int width;

    public GraphicsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        getWindowSize(context);
        setBackgroundResource(R.drawable.gradiente);
    }

    public GraphicsView(Context context) {
        super(context);
        getWindowSize(context);
        setBackgroundResource(R.drawable.gradiente);
    }

    private void getWindowSize(Context context){
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        display.getMetrics(metrics);
        height = metrics.heightPixels;
        width = metrics.widthPixels;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Path circle = new Path();
        circle.addCircle(canvas.getWidth() / 2, canvas.getHeight() / 2, canvas.getWidth() / 3, Path.Direction.CW);
        //circle.addRect(canvas.getWidth() / 2, canvas.getHeight() / 2, canvas.getWidth() / 3, canvas.getWidth() / 3, Path.Direction.CW);
        Paint aPaint = new Paint();
        aPaint.setColor(Color.LTGRAY);
        canvas.drawPath(circle, aPaint);
        Paint bPaint = new Paint();
        bPaint.setColor(Color.BLUE);
        bPaint.setTextSize(70);
        canvas.drawTextOnPath("Mais vale um passáro na mão do que dois voando!", circle, 0, 20, bPaint);
    }
}
