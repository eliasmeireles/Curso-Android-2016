package com.cursoandroid.aula05;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

/**
 * Created by Agripino on 11/04/2016.
 */
public class Keypad extends Dialog {
    private final View keys[] = new View[9];
    private View keypad;
    private final int useds[];
    private final PuzzleView puzzleView;

    public Keypad(Context context, int useds[], PuzzleView puzzleView) {
        super(context);
        this.useds = useds;
        this.puzzleView = puzzleView;
    }

    private void findViews() {
        // TODO: IMPLEMENTAR AQUI O CÓDIGO PARA RECUPERAR AS VIEWS DO KEYPAD
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.keypad_title);
        setContentView(R.layout.keypad);
        findViews();
        for (int element : useds) {
            if (element != 0 && keys[element - 1] != null)
                keys[element - 1].setVisibility(View.INVISIBLE);
        }
        setListeners();
    }

    private void setListeners() {
        for (int i = 0; i < keys.length; i++) {
            final int t = i + 1;
            keys[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    returnResult(t);
                }
            });
        }
        keypad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                returnResult(0);
            }
        });
    }

    private void returnResult(int tile) {
        puzzleView.setSelectedTile(tile);
        dismiss();
    }
}