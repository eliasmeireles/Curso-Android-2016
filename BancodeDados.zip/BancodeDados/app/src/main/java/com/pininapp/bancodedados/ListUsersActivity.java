package com.pininapp.bancodedados;

import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.app.ListActivity;
import android.util.Log;
import android.view.View;

import com.pininapp.bancodedados.db.UsuarioDAO;

public class ListUsersActivity extends ListActivity {

	private List<Usuario> list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData(){
		UsuarioDAO bd = new UsuarioDAO(this);
		list = bd.buscar();
		setListAdapter(new UsuarioAdapter(this, list));
	}

    public void deletar(View v){
        UsuarioDAO bd = new UsuarioDAO(this);
        int id = (int) v.getTag();
        bd.deletar(list.get(id));
        loadData();
        Log.d("ListUsers::deletar", "DELETE");
    }

    public void editar(View v){
        int id = (int) v.getTag();
        Intent intent = new Intent(this, NewUserActivity.class);
        intent.putExtra("nome", list.get(id).getNome());
        intent.putExtra("email", list.get(id).getEmail());
        intent.putExtra("id", list.get(id).getId());
        startActivity(intent);
        Log.d("ListUsers::deletar", "EDITAR");
    }
}
