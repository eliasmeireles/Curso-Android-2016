package com.pininapp.bancodedados.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class BancoDeDados extends SQLiteOpenHelper {
	private static final String NOME_BD = "BancoDeDados";
	private static final int VERSAO_BD = 1;

	
	public BancoDeDados(Context ctx){
		super(ctx, NOME_BD, null, VERSAO_BD);
	}
	
	
	@Override
	public void onCreate(SQLiteDatabase bd) {
        bd.execSQL(UsuarioContract.CREATE_TABLE_SQL);
        Log.d("BancoDeDados", UsuarioContract.CREATE_TABLE_SQL);
    }

	@Override
	public void onUpgrade(SQLiteDatabase bd, int arg1, int arg2) {
	}

}
