package com.pininapp.bancodedados.db;

import android.provider.BaseColumns;

/**
 * Created by Agripino on 20/06/2016.
 */
public interface UsuarioContract extends BaseColumns {
    String TABLE_NAME = "Usuario";
    String NOME = "nome";
    String EMAIL = "email";
    String SENHA = "senha";
    String CREATE_TABLE_SQL = "CREATE TABLE " + TABLE_NAME + " (" +
            _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            NOME + " TEXT NOT NULL, " +
            EMAIL + " TEXT NOT NULL, " +
            SENHA + " TEXT NOT NULL );";

}
