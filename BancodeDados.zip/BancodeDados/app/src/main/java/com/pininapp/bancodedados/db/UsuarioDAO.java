package com.pininapp.bancodedados.db;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.pininapp.bancodedados.Usuario;

public class UsuarioDAO {

	private SQLiteDatabase bd;
	
	public UsuarioDAO(Context context){
		BancoDeDados auxBd = new BancoDeDados(context);
		bd = auxBd.getWritableDatabase();
	}
	
	
	public void inserir(Usuario usuario){
		ContentValues valores = new ContentValues();
		valores.put(UsuarioContract.NOME, usuario.getNome());
		valores.put(UsuarioContract.EMAIL, usuario.getEmail());
		valores.put(UsuarioContract.SENHA, usuario.getSenha());
		bd.insert(
                // Nome da tabela
                UsuarioContract.TABLE_NAME,
                // Valor para tratar colunas nulas
                null,
                // Conjunto de chave/valores para inserir
                valores);
	}
	
	
	public void atualizar(Usuario usuario){
		ContentValues valores = new ContentValues();
        valores.put(UsuarioContract.NOME, usuario.getNome());
        valores.put(UsuarioContract.EMAIL, usuario.getEmail());
		
		bd.update(
                // Nome da tabela
                UsuarioContract.TABLE_NAME,
                // Conjunto de chave/valores para atualizar
                valores,
                // Clausula WHERE
                UsuarioContract._ID + " = ?",
                // Valores da clausula WHERE
                new String[]{""+usuario.getId()});
	}
	
	
	public void deletar(Usuario usuario){
		bd.delete(
                // Nome da tabela
                UsuarioContract.TABLE_NAME,
                // Clausula WHERE
                UsuarioContract._ID + " = ? ",
                // Valores da clausula WHERE
                new String[]{""+usuario.getId()});
	}
	
	
	public List<Usuario> buscar(){
		List<Usuario> list = new ArrayList<Usuario>();
		String[] colunas = new String[]{
                UsuarioContract._ID,
                UsuarioContract.NOME,
                UsuarioContract.EMAIL};
		
		Cursor cursor = bd.query(
                // Nome da tabela
                UsuarioContract.TABLE_NAME,
                // Colunas que serão recuperadas
                colunas,
                // Clausula WHERE
                null,
                // Valores da clausula WHERE
                null,
                // Clausula GROUP BY
                null,
                // Clausula HAVING
                null,
                // Clausula ORDER BY
                UsuarioContract.NOME +" ASC");
		
		if(cursor.getCount() > 0){
            // Move para o primeiro resultado
			cursor.moveToFirst();
			do{
				Usuario u = new Usuario();
				u.setId(cursor.getLong(0));
				u.setNome(cursor.getString(1));
				u.setEmail(cursor.getString(2));
				list.add(u);
				
			}while(cursor.moveToNext());
		}
		return(list);
	}
}
