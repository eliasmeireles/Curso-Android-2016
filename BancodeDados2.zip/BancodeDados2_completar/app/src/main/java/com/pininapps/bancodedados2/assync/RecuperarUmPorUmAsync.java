package com.pininapps.bancodedados2.assync;

import android.content.ContentValues;
import android.os.AsyncTask;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pininapps.bancodedados2.model.Usuario;
import com.pininapps.bancodedados2.web.WebService;

import org.json.JSONArray;
import org.json.JSONObject;

public class RecuperarUmPorUmAsync extends AsyncTask<Void, Usuario, Boolean>{

    private RecuperarUmPorUmAsyncCallback callback;

    public RecuperarUmPorUmAsync(RecuperarUmPorUmAsyncCallback callback){
        this.callback = callback;
    }
    @Override
    protected Boolean doInBackground(Void... params) {
        ContentValues cv = new ContentValues();
        cv.put("req", "listaUmPorUm");

        // TODO: INSERIR O CÓDIGO PARA BUSCAR OS REGISTROS E ENVIAR A NOTIFICAÇÃO DE PROGRESSO

        return false;
    }

    @Override
    protected void onProgressUpdate(Usuario... values) {
        callback.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(Boolean resultado) {
        callback.resultado(resultado);
    }

    public interface RecuperarUmPorUmAsyncCallback{
        void resultado(boolean resultado);
        void onProgressUpdate(Usuario... usuario);
    }
}
