package com.pininapps.bancodedados2;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.pininapps.bancodedados2.adapter.UsuarioAdapter;
import com.pininapps.bancodedados2.assync.RecuperarTodosAsync;
import com.pininapps.bancodedados2.assync.RecuperarUmPorUmAsync;
import com.pininapps.bancodedados2.model.Usuario;

import java.util.ArrayList;
import java.util.List;

public class ListaItensActivity extends ListActivity
        implements View.OnClickListener, RecuperarTodosAsync.RecuperarTodosAsyncCallback,
        RecuperarUmPorUmAsync.RecuperarUmPorUmAsyncCallback{

    private ListView list;
    private View emptyList;
    private Button limpar;
    private Button recuperar;
    private RadioButton radioTodos;
    private RadioButton radioUmPorUm;

    private List<Usuario> usuarios;

    private ProgressDialog progressDialog;
    private boolean buscandoUmPorUm = false;

    private void findViews() {
        list = (ListView)findViewById( android.R.id.list );
        emptyList = findViewById( R.id.emptyList );
        limpar = (Button)findViewById( R.id.limpar );
        recuperar = (Button)findViewById( R.id.recuperar );
        radioTodos = (RadioButton)findViewById( R.id.radioTodos );
        radioUmPorUm = (RadioButton)findViewById( R.id.radioUmPorUm );

        limpar.setOnClickListener( this );
        recuperar.setOnClickListener( this );
    }
    @Override
    public void onClick(View v) {
        if ( v == limpar ) {

            // Limpar a lista
            usuarios = new ArrayList<>();

            // Reiniciar o adapter
            list.setAdapter(new UsuarioAdapter(this, usuarios));

            // Verificar as habilitações dos botões e atualizar a lista
            habilitarBotoesEAtualizarLista();

        } else if ( v == recuperar ) {
            if(radioTodos.isChecked()){

                // Chamar a task para recuperar todos
                RecuperarTodosAsync task = new RecuperarTodosAsync(this);
                task.execute();

                // Exibir um dialog de progresso
                progressDialog = new ProgressDialog(this);
                progressDialog.setTitle(R.string.recuperando_lista);
                progressDialog.setCancelable(false);
                progressDialog.show();
            }

            else {

                buscandoUmPorUm = true;

                // Chamar a task para recuperar todos
                RecuperarUmPorUmAsync task = new RecuperarUmPorUmAsync(this);
                task.execute();
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_itens);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViews();

        // Verificar as habilitações dos botões e atualizar a lista
        habilitarBotoesEAtualizarLista();
    }

    private void habilitarBotoesEAtualizarLista() {
        // Ativar ou desativar a view de lista vazia e p botão limpar
        if(usuarios == null || usuarios.size() <=0 ){

            getSupportActionBar().setTitle(R.string.lista);

            emptyList.setVisibility(View.VISIBLE);
            list.setVisibility(View.GONE);
            limpar.setEnabled(false);
            recuperar.setEnabled(true);
            radioTodos.setEnabled(true);
            radioUmPorUm.setEnabled(true);
        }
        else{
            getSupportActionBar().setTitle(getString(R.string.lista_x, usuarios.size()));

            emptyList.setVisibility(View.GONE);
            list.setVisibility(View.VISIBLE);
            if(!buscandoUmPorUm) {
                limpar.setEnabled(true);
            }
            else{
                limpar.setEnabled(false);
            }
            recuperar.setEnabled(false);
            radioTodos.setEnabled(false);
            radioUmPorUm.setEnabled(false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.profile:
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.deseja_sair);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.sim, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(ListaItensActivity.this, LoginActivity.class));
                ListaItensActivity.super.onBackPressed();
            }
        });
        builder.setPositiveButton(R.string.nao, null);
        builder.show();
    }

    @Override
    public void resultado(List<Usuario> usuarios) {

        // Remover o dialogo
        progressDialog.dismiss();

        if (usuarios != null) {

            // Atualizar a lista
            this.usuarios = usuarios;

            // Adicionar os registros na lista
            list.setAdapter(new UsuarioAdapter(this, usuarios));

            // Verificar as habilitações dos botões e atualizar a lista
            habilitarBotoesEAtualizarLista();
        }
        //Tratar erro de servidor]
        else{
            Toast.makeText(this, R.string.nao_foi_possivel_conectar_ao_servidor, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void resultado(boolean resultado) {
        buscandoUmPorUm = false;
        Toast.makeText(this, R.string.todos_os_registros_foram_recuperados, Toast.LENGTH_SHORT).show();

        // Adicionar os registros na lista
        ((UsuarioAdapter)list.getAdapter()).notifyDataSetChanged();

        // Verificar as habilitações dos botões e atualizar a lista
        habilitarBotoesEAtualizarLista();
    }

    @Override
    public void onProgressUpdate(Usuario... usuarios) {

        // checar se a lista ainda está nula
        if (this.usuarios == null) {
            this.usuarios = new ArrayList<>();
            list.setAdapter(new UsuarioAdapter(this, this.usuarios));
        }

        // Atualizar a lista
        for(Usuario u : usuarios) {
            this.usuarios.add(u);
            //Toast.makeText(this, getString(R.string.usuario_recuperado, u.nome), Toast.LENGTH_SHORT).show();
        }

        // Adicionar os registros na lista
        ((UsuarioAdapter)list.getAdapter()).notifyDataSetChanged();

        // Verificar as habilitações dos botões e atualizar a lista
        habilitarBotoesEAtualizarLista();
    }
}
