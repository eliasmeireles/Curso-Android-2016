package com.pininapps.bancodedados2;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.pininapps.bancodedados2.assync.LoginAsync;
import com.pininapps.bancodedados2.web.WebService;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, LoginAsync.LoginAsyncCallback {

    private ProgressDialog progressDialog;

    private EditText email;
    private EditText senha;
    private Button loginButton;

    private void findViews() {
        email = (EditText)findViewById( R.id.email );
        senha = (EditText)findViewById( R.id.senha );
        loginButton = (Button)findViewById( R.id.loginButton );
        loginButton.setOnClickListener( this );
    }

    @Override
    public void onClick(View v) {
        if ( v == loginButton ) {
            int qtdErros = 0;

            //Remover a mensagem de erro dos campos
            email.setError(null);
            senha.setError(null);

            // Verificar campos obrigatórios
            if(email.getText().toString().length() <= 0){
                qtdErros++;
                email.setError(getResources().getQuantityString(R.plurals.campo_obrigatorio_nao_preenchido, 1));
            }
            if(senha.getText().toString().length() <= 0){
                qtdErros++;
                senha.setError(getResources().getQuantityString(R.plurals.campo_obrigatorio_nao_preenchido, 1));
            }

            // Se tem erro exibir um alerta
            if(qtdErros > 0){
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getResources().getQuantityString(R.plurals.campo_obrigatorio_nao_preenchido, qtdErros));
                builder.setMessage(R.string.verifique_os_erros_e_tente_novamente);
                builder.setPositiveButton(R.string.ok, null);
                builder.setCancelable(false);
                builder.show();
            }
            // Se não tem erro chamar o webService
            else{
                // Agrupar os valores
                ContentValues cv = new ContentValues();
                cv.put("req", "login");
                cv.put("email", email.getText().toString());
                cv.put("senha", senha.getText().toString());

                // Chamar a task asincrona
                LoginAsync task = new LoginAsync(this, this);
                task.execute(cv);

                // Exibir um dialog de progresso
                progressDialog = new ProgressDialog(this);
                progressDialog.setTitle(R.string.realizando_login);
                progressDialog.setCancelable(false);
                progressDialog.show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViews();
    }

    @Override
    public void resultado(Boolean resultado) {

        // Remover o dialogo
        progressDialog.dismiss();

        // Tratar erro de resposta
        if(resultado == null){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.tente_mais_tarde);
            builder.setMessage(R.string.nao_foi_possivel_conectar_ao_servidor);
            builder.setCancelable(false);
            builder.setPositiveButton(R.string.ok, null);
            builder.show();
        }
        else{
            // Tratar erro de login
            if(!resultado){
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(R.string.email_e_senha_nao_conferem);
                builder.setMessage(R.string.verifique_os_dados_e_tente_novamente);
                builder.setCancelable(false);
                builder.setPositiveButton(R.string.ok, null);
                builder.show();
            }
            // Login com sucesso
            else{
                Toast.makeText(this, R.string.login_realizado_com_sucesso, Toast.LENGTH_SHORT).show();
                // Abrir a próxima activity
                startActivity(new Intent(this, ListaItensActivity.class));
                // Finalizar a activity login
                finish();
            }
        }
    }
}
