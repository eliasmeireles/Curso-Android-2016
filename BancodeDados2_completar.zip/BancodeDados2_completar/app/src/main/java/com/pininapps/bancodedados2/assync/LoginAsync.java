package com.pininapps.bancodedados2.assync;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pininapps.bancodedados2.model.Usuario;
import com.pininapps.bancodedados2.web.WebService;

import org.json.JSONObject;


public class LoginAsync extends AsyncTask<ContentValues, Void, Boolean> {

    private Context context;
    private LoginAsyncCallback callback;

    public LoginAsync(Context context, LoginAsyncCallback callback){
        this.context = context;
        this.callback = callback;
    }

    @Override
    protected Boolean doInBackground(ContentValues... params) {
        try {
            JSONObject jsonResponse = WebService.executeJSONQuery(params[0]);
            boolean sucesso = jsonResponse.getBoolean("sucesso");
            if(sucesso){

                // TODO: Recuperar o cliente a partir do JSON

                // TODO: Validar JSON (opcional). Se der uma exception será tratado pelo catch (abaixo)

                // TODO: Salvar o usuário como json no SharedPReferences
            }
            return sucesso;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(Boolean resultado) {
        callback.resultado(resultado);
    }

    public interface LoginAsyncCallback{
        void resultado(Boolean resultado);
    }
}


