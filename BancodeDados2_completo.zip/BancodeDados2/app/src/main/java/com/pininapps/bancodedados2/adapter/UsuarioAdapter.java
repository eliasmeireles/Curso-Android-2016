package com.pininapps.bancodedados2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pininapps.bancodedados2.R;
import com.pininapps.bancodedados2.model.Usuario;

import java.util.List;

public class UsuarioAdapter extends BaseAdapter {
	private Context context;
	private List<Usuario> list;
	
	public UsuarioAdapter(Context context, List<Usuario> list){
		this.context = context;
		this.list = list;
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		return list.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    @Override
	public View getView(int position, View arg1, ViewGroup arg2) {
		
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		final LinearLayout layout = (LinearLayout) inflater.inflate(R.layout.usuario, null);

		TextView tv = (TextView) layout.findViewById(R.id.nome);
		tv.setText(list.get(position).nome);

		tv = (TextView) layout.findViewById(R.id.email);
		tv.setText(list.get(position).email);

		tv = (TextView) layout.findViewById(R.id.telefone);
		tv.setText(list.get(position).telefone);
		
		return layout;
	}

}
