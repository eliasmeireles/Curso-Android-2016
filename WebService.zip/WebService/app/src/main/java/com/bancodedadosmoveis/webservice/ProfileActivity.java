package com.bancodedadosmoveis.webservice;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.bancodedadosmoveis.webservice.model.Usuario;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class ProfileActivity extends AppCompatActivity {
    private EditText nome;
    private EditText email;
    private EditText nascimento;
    private RadioButton radioMasc;
    private RadioButton radioFem;
    private EditText telefone;
    private TextView cadastradoEm;

    private void findViews() {
        nome = (EditText)findViewById( R.id.nome );
        email = (EditText)findViewById( R.id.email );
        nascimento = (EditText)findViewById( R.id.nascimento );
        radioMasc = (RadioButton)findViewById( R.id.radioMasc );
        radioFem = (RadioButton)findViewById( R.id.radioFem );
        telefone = (EditText)findViewById( R.id.telefone );
        cadastradoEm = (TextView)findViewById( R.id.cadastradoEm );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViews();

        popularCampos();
    }

    private void popularCampos() {
        String jsonUsuario = getSharedPreferences("SHARED_PREF", MODE_PRIVATE).getString("USUARIO", null);
        if(jsonUsuario != null){
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            Usuario usuario = gson.fromJson(jsonUsuario, Usuario.class);
            nome.setText(usuario.nome);
            email.setText(usuario.email);
            nascimento.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(usuario.nascimento));
            radioMasc.setChecked(usuario.sexo == 'M');
            radioFem.setChecked(usuario.sexo == 'F');
            telefone.setText(usuario.telefone);
            cadastradoEm.setText(getString(R.string.usuario_cadastrado_desde,
                    new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(usuario.dataCadastro)));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
