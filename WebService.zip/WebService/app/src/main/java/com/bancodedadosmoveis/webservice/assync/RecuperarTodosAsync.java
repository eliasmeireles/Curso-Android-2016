package com.bancodedadosmoveis.webservice.assync;

import android.content.ContentValues;
import android.os.AsyncTask;

import com.bancodedadosmoveis.webservice.model.Usuario;
import com.bancodedadosmoveis.webservice.web.WebService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RecuperarTodosAsync extends AsyncTask<Void, Void, List<Usuario>> {

    private RecuperarTodosAsyncCallback callback;

    public RecuperarTodosAsync(RecuperarTodosAsyncCallback callback){
        this.callback = callback;
    }
    @Override
    protected List<Usuario> doInBackground(Void... params) {
        ContentValues cv = new ContentValues();
        cv.put("req", "listaTodos");
        try {
            JSONObject jsonResponse = WebService.executeJSONQuery(cv);
            boolean sucesso = jsonResponse.getBoolean("sucesso");
            if (sucesso) {
                List<Usuario> usuarios = new ArrayList<>();

                // TODO: INSERIR O CÓDIGO PARA TRATAR O RETORNO DOS REGISTROS

                try {
                    Thread.sleep(1500);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

                return usuarios;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(List<Usuario> usuarios) {
        callback.resultado(usuarios);
    }
    public interface RecuperarTodosAsyncCallback{
        void resultado(List<Usuario> usuarios);
    }
}
