package com.bancodedadosmoveis.webservice.assync;

import android.content.ContentValues;
import android.os.AsyncTask;

import com.bancodedadosmoveis.webservice.model.Usuario;
import com.bancodedadosmoveis.webservice.web.WebService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

public class RecuperarUmPorUmAsync extends AsyncTask<Void, Usuario, Boolean> {

    private RecuperarUmPorUmAsyncCallback callback;

    public RecuperarUmPorUmAsync(RecuperarUmPorUmAsyncCallback callback){
        this.callback = callback;
    }
    @Override
    protected Boolean doInBackground(Void... params) {
        ContentValues cv = new ContentValues();
        cv.put("req", "listaUmPorUm");
        try {
            for(int cont = 0; ; cont++) {
                cv.put("num", cont);
                JSONObject jsonResponse = WebService.executeJSONQuery(cv);
                boolean sucesso = jsonResponse.getBoolean("sucesso");
                if (sucesso) {
                    // TODO: INSERIR O CÓDIGO PARA BUSCAR OS REGISTROS E ENVIAR A NOTIFICAÇÃO DE PROGRESSO

                    try {
                        Thread.sleep(1500);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    protected void onProgressUpdate(Usuario... values) {
        callback.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(Boolean resultado) {
        callback.resultado(resultado);
    }

    public interface RecuperarUmPorUmAsyncCallback{
        void resultado(boolean resultado);
        void onProgressUpdate(Usuario... usuario);
    }
}
