package com.bancodedadosmoveis.webservice.web;

import android.content.ContentValues;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

public class WebService {
    public static JSONObject executeJSONQuery(ContentValues values)
            throws JSONException {

        URL url;
        HttpURLConnection conn;
        JSONObject jArray = null;

        // build the string to store the response text from the server
        String response = "";

        try {
            // if you are using https, make sure to import
            // java.net.HttpsURLConnection
            url = new URL("http://i3t.com.br/android/android.php?");

            // you need to encode ONLY the values of the parameters
            String param = "";
            for (String key : values.keySet()) {
                Object value = values.get(key);
                param += key + "=" + URLEncoder.encode(value != null ? values.getAsString(key) : "", "UTF-8") + "&";
            }

            conn = (HttpURLConnection) url.openConnection();
            // set the output to true, indicating you are outputting(uploading)
            // POST data
            conn.setDoOutput(true);
            // once you set the output to true, you don't really need to set the
            // request method to post, but I'm doing it anyway
            conn.setRequestMethod("POST");
            //conn.setConnectTimeout(2000);
            //conn.setReadTimeout(5000);

            // Android documentation suggested that you set the length of the
            // data you are sending to the server, BUT
            // do NOT specify this length in the header by using
            // conn.setRequestProperty("Content-Length", length);
            // use this instead.
            conn.setFixedLengthStreamingMode(param.getBytes().length);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // send the POST out
            PrintWriter out = new PrintWriter(conn.getOutputStream());
            out.print(param);
            out.close();

            // start listening to the stream
            Scanner inStream = new Scanner(conn.getInputStream());

            // process the stream and store it in StringBuilder
            while (inStream.hasNextLine()) {
                response += (inStream.nextLine());
            }

            inStream.close();

            jArray = new JSONObject(response);

        } catch (Exception ex) {
            ex.printStackTrace();
            Log.d("ERROR JSON STRING", response);
            throw new JSONException("JsonError");
        }
        return jArray;
    }
}
