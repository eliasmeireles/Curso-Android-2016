package com.bancodedadosmoveis.webservice.assync;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import com.bancodedadosmoveis.webservice.model.Usuario;
import com.bancodedadosmoveis.webservice.web.WebService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;


public class LoginAsync extends AsyncTask<ContentValues, Void, Boolean> {

    private Context context;
    private LoginAsyncCallback callback;

    public LoginAsync(Context context, LoginAsyncCallback callback){
        this.context = context;
        this.callback = callback;
    }

    @Override
    protected Boolean doInBackground(ContentValues... params) {
        try {
            JSONObject jsonResponse = WebService.executeJSONQuery(params[0]);
            boolean sucesso = jsonResponse.getBoolean("sucesso");
            if(sucesso){

                // Recuperar o cliente a partir do JSON
                JSONObject jsonCliente = jsonResponse.getJSONArray("cliente").getJSONObject(0);
                String usuarioJson = jsonCliente.toString();

                // Validar JSON (opcional)
                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
                // Se der uma exception será tratado pelo catch (abaixo)
                Usuario u = gson.fromJson(usuarioJson, Usuario.class);

                // Salvar o usuário como json no SharedPReferences
                SharedPreferences prefs = context.getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("USUARIO", usuarioJson);
                editor.apply();
            }
            return sucesso;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(Boolean resultado) {
        callback.resultado(resultado);
    }

    public interface LoginAsyncCallback{
        void resultado(Boolean resultado);
    }
}


