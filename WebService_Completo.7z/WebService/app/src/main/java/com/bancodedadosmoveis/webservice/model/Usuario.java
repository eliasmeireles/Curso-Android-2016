package com.bancodedadosmoveis.webservice.model;

import java.util.Date;

public class Usuario {
	public String nome;
	public String email;
	public Date nascimento;
	public Date dataCadastro;
	public String telefone;
	public char sexo;
}
